/*    ======================================= 
    Copyright 1998 - 2010 - E Net Arch 
    This program is distributed under the terms of the GNU  
    General Public License (or the Lesser GPL). 
    ======================================= */ 

var LadderContainers = function () 
{
    var self = this;
    
    LadderContainers.SUPER.call (self);        
};
LadderNodes.extends (LadderContainers);

