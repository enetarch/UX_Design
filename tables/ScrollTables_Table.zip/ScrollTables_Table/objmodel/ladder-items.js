/*    ======================================= 
    Copyright 1998 - 2010 - E Net Arch 
    This program is distributed under the terms of the GNU  
    General Public License (or the Lesser GPL). 
    ======================================= */ 

var LadderItems = function () 
{
    var self = this;
    LadderItem.SUPER.call (this);
};
LadderNodes.extends (LadderItems);
